# 9JA Vendors

Product-first marketplace promoting **authentic Nigerian vendors**.

Browse fashion, Ankara, foodstuff, FMCG, home appliances, bags, shoes and fabrics — with clear prices, available quantities and product descriptions.

## What changed

- Product catalogue (not vendor-profile-first)
- Categories for FMCG, home, appliances, foodstuff, clothing, bags, shoes, Ankara and fabrics
- Each product has description, quantity available and affordable ₦ prices
- Sign-in / sign-up and vendor profile browsing removed from the main experience

## Stack

TanStack Start, React, Tailwind, Vite. See `package.json`.

## Develop

```bash
bun install
bun run dev
```

## Note

Product images live in `public/products/{product-id}.jpg` (quality stock photos as placeholders). Replace those files with your real product photos using the same filenames — no code change needed.
