# 9JA Vendors roadmap

- [x] Product-first marketplace home and category browse
- [x] Seeded catalogue: FMCG, home, appliances, foodstuff, fashion, bags, shoes, Ankara, fabrics
- [x] Product detail pages with price, quantity and description
- [x] Remove sign-up / sign-in from primary navigation
- [x] Remove vendor profile as primary browsing model
- [ ] Real product photography
- [ ] Vendor onboarding (when needed)
- [ ] Final validation
