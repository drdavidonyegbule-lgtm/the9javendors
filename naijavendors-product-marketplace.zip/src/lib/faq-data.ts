export const faqs = [
  {
    q: "What is 9JA Vendors?",
    a: "9JA Vendors is a product marketplace that promotes the authenticity of Nigerian vendors. Browse fashion, Ankara, foodstuff, FMCG, home appliances and more — with clear prices and available quantities.",
  },
  {
    q: "How is this different from other marketplaces?",
    a: "We focus on authentic Nigerian sellers and a product-first experience: you see product images, descriptions, stock levels and affordable naira prices — not vendor profile pages as the main journey.",
  },
  {
    q: "What product categories are available?",
    a: "FMCG & everyday essentials, home & kitchen, home appliances, foodstuff & groceries, men's and women's clothing, bags & accessories, shoes, Ankara & traditional wear, and fabrics & textiles.",
  },
  {
    q: "Do products show quantity and price?",
    a: "Yes. Every product listing includes description, number of units available and price in Nigerian naira (₦).",
  },
  {
    q: "Do I need an account to browse?",
    a: "No. Anyone can browse and view products without signing up.",
  },
  {
    q: "How do I contact a seller?",
    a: "Open a product page and use Enquire about this product, or visit the Contact page. Arrange payment and delivery directly with the vendor.",
  },
  {
    q: "Does 9JA Vendors handle payments?",
    a: "Not currently. You arrange payment and delivery directly with the vendor. Always confirm details before paying.",
  },
  {
    q: "Can I install the app on my phone?",
    a: "Yes. Open the site in your phone browser and choose Add to Home Screen or Install app. Key pages keep working offline.",
  },
  {
    q: "Can I use dark mode?",
    a: "Yes. Tap the sun/moon button in the top bar to switch between light and dark mode.",
  },
];

export const siteMap = [
  { path: "/", label: "Home — search and featured products" },
  { path: "/categories", label: "Categories — browse and filter all products" },
  { path: "/how-it-works", label: "How it works" },
  { path: "/faq", label: "FAQ" },
  { path: "/contact", label: "Contact" },
];
