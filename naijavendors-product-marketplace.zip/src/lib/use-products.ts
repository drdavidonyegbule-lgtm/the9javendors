import { products, type MarketplaceProduct } from "./marketplace-data";

export type { MarketplaceProduct };

/** Product catalogue hook — currently seeded local data (product-first marketplace). */
export function useProducts(): MarketplaceProduct[] {
  return products;
}

export function getProductById(id: string): MarketplaceProduct | undefined {
  return products.find((p) => p.id === id);
}
