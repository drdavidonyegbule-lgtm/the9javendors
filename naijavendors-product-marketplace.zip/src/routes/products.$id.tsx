import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ChevronLeft, MapPin, Package, Store } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { ProductCard } from "@/components/product-card";
import { Button } from "@/components/ui/button";
import { getProductById, useProducts } from "@/lib/use-products";

export const Route = createFileRoute("/products/$id")({
  loader: ({ params }) => {
    const product = getProductById(params.id);
    if (!product) throw notFound();
    return product;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.title} — 9JA Vendors` : "Product not found — 9JA Vendors" },
      { name: "description", content: loaderData?.description ?? "Discover authentic Nigerian products on 9JA Vendors." },
      { property: "og:title", content: loaderData ? `${loaderData.title} — 9JA Vendors` : "Product not found — 9JA Vendors" },
      { property: "og:description", content: loaderData?.description ?? "Discover authentic Nigerian products on 9JA Vendors." },
      { property: "og:type", content: "product" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductPage,
  notFoundComponent: () => (
    <PageShell>
      <div className="mx-auto max-w-7xl px-4 py-24">
        <h1 className="text-3xl font-bold">Product not found</h1>
        <Button className="mt-6" asChild>
          <Link to="/categories">Browse products</Link>
        </Button>
      </div>
    </PageShell>
  ),
});

function ProductPage() {
  const product = Route.useLoaderData();
  const related = useProducts()
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);
  const inStock = product.quantity > 0;

  return (
    <PageShell>
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Link
          to="/categories"
          className="inline-flex items-center gap-1 text-sm font-medium text-muted-foreground hover:text-primary"
        >
          <ChevronLeft className="size-4" /> All products
        </Link>

        <div className="mt-6 grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
          <img
            src={product.image}
            alt={product.title}
            width={1536}
            height={896}
            className="aspect-[4/3] w-full rounded-lg object-cover"
          />
          <div className="flex flex-col justify-center">
            <p className="text-xs font-bold uppercase tracking-widest text-primary">{product.category}</p>
            <h1 className="mt-3 text-3xl font-bold sm:text-4xl lg:text-5xl">{product.title}</h1>
            <p className="mt-5 text-3xl font-bold text-primary">
              ₦{product.price.toLocaleString("en-NG")}
            </p>
            <div className="mt-5 flex flex-wrap items-center gap-5 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <Package className="size-4" />
                {inStock ? (
                  <span>
                    <strong className="text-foreground">{product.quantity}</strong> available
                  </span>
                ) : (
                  "Out of stock"
                )}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="size-4" />
                {product.location}
              </span>
            </div>
            <p className="mt-7 max-w-lg text-lg leading-8 text-muted-foreground">{product.description}</p>
            <div className="mt-8 rounded-lg border border-border bg-card p-5">
              <p className="flex items-center gap-2 text-sm font-semibold">
                <Store className="size-4 text-primary" />
                Sold by authentic Nigerian vendor
              </p>
              <p className="mt-2 text-lg font-bold">{product.vendorName}</p>
              <p className="mt-1 text-sm text-muted-foreground">{product.location}</p>
            </div>
            {product.tags && product.tags.length > 0 && (
              <div className="mt-6 flex flex-wrap gap-2">
                {product.tags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-border bg-muted px-3 py-1 text-xs font-medium text-muted-foreground"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" asChild>
                <Link to="/contact">Enquire about this product</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/categories">Continue shopping</Link>
              </Button>
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <div className="mt-16 border-t border-border py-12">
            <h2 className="text-2xl font-bold">More in {product.category}</h2>
            <div className="mt-7 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </PageShell>
  );
}
