import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";

import marketplaceImage from "@/assets/nigerian-marketplace.jpg";
import { ProductCard } from "@/components/ProductCard";
import { SiteLayout } from "@/components/SiteLayout";
import { buttonAccent, buttonGhost } from "@/components/ui-classes";
import { listProducts } from "@/lib/shop.functions";

const productsQuery = queryOptions({
  queryKey: ["products", "public"],
  queryFn: () => listProducts(),
});

export const Route = createFileRoute("/")({
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(productsQuery);
  },
  head: () => ({
    meta: [
      { title: "9Ja Vendors — From the trade fair floor to your door" },
      {
        name: "description",
        content:
          "9Ja Vendors connects young Nigerian entrepreneurs at trade fairs to digital payments and an online store. Browse products, pay securely, and we deliver.",
      },
      {
        property: "og:title",
        content: "9Ja Vendors — From the trade fair floor to your door",
      },
      {
        property: "og:description",
        content:
          "9Ja Vendors connects young Nigerian entrepreneurs at trade fairs to digital payments and an online store.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
  errorComponent: () => (
    <SiteLayout>
      <div className="mx-auto max-w-3xl px-5 py-24 text-center">
        <h1 className="text-2xl font-bold">We could not load the shop</h1>
        <p className="mt-3 text-muted-foreground">Please refresh the page and try again.</p>
      </div>
    </SiteLayout>
  ),
});

function HomePage() {
  const { data: products } = useSuspenseQuery(productsQuery);
  const featured = products.filter((product) => product.isAvailable).slice(0, 4);
  const categories = Array.from(new Set(products.map((product) => product.category))).slice(0, 6);

  return (
    <SiteLayout>
      {/* Hero: the marketplace photo carries the story — trade fair energy, real vendors. */}
      <section className="relative overflow-hidden bg-accent text-accent-foreground">
        <div className="mx-auto grid w-full max-w-6xl items-stretch gap-0 lg:grid-cols-[1.05fr_1fr]">
          <div className="flex flex-col justify-center px-5 py-16 sm:py-20 lg:px-8 lg:py-28">
            <h1 className="text-balance-tight text-4xl font-extrabold leading-[1.03] sm:text-5xl lg:text-[3.4rem]">
              Every vendor starts at a trade fair. Their customers don't have to.
            </h1>
            <p className="mt-6 max-w-md text-base text-accent-foreground/80 sm:text-lg">
              9Ja Vendors takes the hustle from the market floor and puts it online — real vendors,
              real prices, secure payment, delivered to your door.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link to="/shop" className={buttonAccent}>
                Shop the store
              </Link>
              <Link
                to="/directory"
                className="inline-flex items-center justify-center gap-2 rounded-sm border border-white/30 px-6 py-3 text-sm font-bold text-accent-foreground transition hover:bg-white/10"
              >
                Browse vendors
              </Link>
            </div>
          </div>
          <div className="relative min-h-[280px] lg:min-h-0">
            <img
              src={marketplaceImage}
              alt="Vendors at a Nigerian trade fair selling crafts, jewelry, and beauty products under green-and-white tents"
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="adire-band absolute inset-x-0 top-0" aria-hidden="true" />
          </div>
        </div>
      </section>

      {/* This is a genuine sequence — the platform's actual onboarding path — not a decorative 01/02/03. */}
      <section className="mx-auto w-full max-w-6xl px-5 py-16 lg:py-20">
        <h2 className="text-2xl font-extrabold sm:text-3xl">How a vendor gets here</h2>
        <div className="mt-8 grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-3">
          {[
            {
              step: "At the fair",
              body: "A vendor sets up a stall, sells in person, and gets onboarded onto digital payment rails on the spot with a QR terminal.",
            },
            {
              step: "Account carries over",
              body: "Their sales history and product catalog move with them onto the marketplace — no re-entering everything from scratch.",
            },
            {
              step: "Selling online",
              body: "Customers browse the storefront, pay securely, and the vendor keeps trading long after the fair tents come down.",
            },
          ].map((item) => (
            <div key={item.step} className="bg-card p-6 sm:p-7">
              <h3 className="text-base font-bold">{item.step}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{item.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto w-full max-w-6xl px-5 pb-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-extrabold sm:text-3xl">Available now</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Fresh stock our team can source for you today.
            </p>
          </div>
          <Link to="/shop" className={buttonGhost}>
            See all products
          </Link>
        </div>

        {featured.length === 0 ? (
          <p className="mt-10 rounded-lg border border-border bg-card p-8 text-sm text-muted-foreground">
            New products are being added. Please check back shortly.
          </p>
        ) : (
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        {categories.length > 0 ? (
          <div className="mt-12 flex flex-wrap gap-3">
            {categories.map((category) => (
              <Link
                key={category}
                to="/shop"
                search={{ category }}
                className="rounded-sm border border-border bg-panel px-4 py-2 text-sm text-muted-foreground transition hover:border-primary/60 hover:text-foreground"
              >
                {category}
              </Link>
            ))}
          </div>
        ) : null}
      </section>
    </SiteLayout>
  );
}
