// Shared class tokens. Radius is used with intent, not uniformly:
// interactive controls (buttons, inputs) stay sharp-ish (radius-sm);
// containers that hold content (cards, panels) get a touch more (radius-lg).

export const buttonPrimary =
  "inline-flex items-center justify-center gap-2 rounded-sm bg-primary px-6 py-3 text-sm font-bold text-primary-foreground transition hover:bg-accent focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:cursor-not-allowed disabled:opacity-60";

export const buttonAccent =
  "inline-flex items-center justify-center gap-2 rounded-sm bg-terracotta px-6 py-3 text-sm font-bold text-white transition hover:brightness-95 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:cursor-not-allowed disabled:opacity-60";

export const buttonGhost =
  "inline-flex items-center justify-center gap-2 rounded-sm border border-border bg-transparent px-6 py-3 text-sm font-bold text-foreground transition hover:bg-secondary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring disabled:cursor-not-allowed disabled:opacity-60";

export const buttonSmall =
  "inline-flex items-center justify-center gap-1.5 rounded-sm border border-border px-3 py-1.5 text-xs font-bold text-foreground transition hover:bg-secondary disabled:opacity-50";

export const inputBase =
  "w-full rounded-sm border border-input bg-panel px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:border-primary focus-visible:outline-none";

export const labelBase = "mb-2 block text-xs font-semibold text-muted-foreground";

export const cardBase = "rounded-lg border border-border bg-card p-6 shadow-panel";

export const panelBase = "rounded-lg border border-border bg-panel p-6";
